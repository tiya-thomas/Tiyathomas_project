from django import forms
from .models import *
class RegisterForm(forms.ModelForm):
    class Meta:
        model=Register
        fields=['username','email','password','image','phone_number']

class productsForm(forms.ModelForm):
    class Meta:
        model=Clothes
        fields=['name','brand','category','price','stock','description','image','quantity']
