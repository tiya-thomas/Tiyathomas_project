from django.shortcuts import render,redirect
from django.contrib.auth import login,logout,authenticate
from .models import *
from .forms import *

# Create your views here.
from django.http import HttpResponse
def chat(request):
    return  HttpResponse("hello world")
def home_page(request):
    return render(request,'home.html')
def about(request):
    return render(request,'about.html')
def register(request):
    # if request.method=='POST':
    #     u_name=request.POST['name']
    #     e_mail=request.POST['email']
    #     password=request.POST['password']
    #     Register.objects.create_user(username=u_name,email=e_mail,password=password,usertype='user')
    #     return redirect('/')
    form = RegisterForm(request.POST,request.FILES)
    if request.method=='POST':
        if form.is_valid():
            form.save()
            return redirect('/')
    return render(request,'register.html',{'form':form})
def login_user(request):
    if request.method == 'POST':
        username=request.POST['name']
        password=request.POST['password']
        user=authenticate(request,username=username,password=password)
        print(user,"mkm")
        if user is not None:
            login(request,user)
            return redirect('/')
    return render(request,'login.html')
def add_products(request):
    # if request.method=='POST':
    #     u_name=request.POST['name']
    #     e_mail=request.POST['email']
    #     password=request.POST['password']
    #     Register.objects.create_user(username=u_name,email=e_mail,password=password,usertype='user')
    #     return redirect('/')
    form = productsForm(request.POST,request.FILES)
    if request.method=='POST':
        if form.is_valid():
            form.save()
            return redirect('/')
    return render(request,'products.html',{'form':form})
 