from django.db import models

# Create your models here.
from django.contrib.auth.models import AbstractUser
class Register(AbstractUser):
    usertype=models.CharField(max_length=100,null=True,default='admin')
    image=models.FileField(upload_to='profile_image',null=True)
    phone_number=models.PositiveIntegerField(default=0,null=True)

class Clothes(models.Model):
    CATEGORY_CHOICES = [
        ('Men', 'Men'),
        ('Women', 'Women'),
        ('Kids', 'Kids'),
    ]

    name = models.CharField(max_length=100)
    brand = models.CharField(max_length=100)
    category = models.CharField(max_length=10, choices=CATEGORY_CHOICES)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    stock = models.PositiveIntegerField()
    description = models.TextField(blank=True)
    image = models.ImageField(upload_to='clothes/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    quantity=models.CharField(max_length=100,null=True)


    def __str__(self):
        return self.name
