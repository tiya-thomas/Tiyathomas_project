from django.urls import path
from.import views
urlpatterns=[
    path('chat/',views.chat,name='chat'),
    path('',views.home_page,name='index'),
    path('about',views.about,name='index'),
    path('register',views.register,name='register'),
    path('login',views.login_user),
    path('add_products',views.add_products,name='add_products')
    ]